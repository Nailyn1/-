from cryptography.fernet import Fernet
def load_key():
# Загружаем ключ 'crypto.key' из текущего каталога
    return open('crypto.key', 'rb').read()

def encrypt(filename, key):
# Зашифруем файл и записываем его
    f = Fernet(key)
    with open(filename, 'rb') as file:
    # прочитать все данные файла
        file_data = file.read()
        encrypted_data = f.encrypt(file_data)
    # записать зашифрованный файл
    with open(filename, 'wb') as file:
        file.write(encrypted_data)

key = load_key()
# имя шифруемого файла
file = 'primercrypt.txt'
# зашифровать файл
encrypt(file, key)