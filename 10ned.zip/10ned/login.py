from tkinter import *
from tkinter import messagebox
from cryptography.fernet import Fernet

def load_key():
# Загружаем ключ 'crypto.key' из текущего каталога
    return open('crypto.key', 'rb').read()

def decrypt(filename, key):
# Расшифруем файл и записываем его
    f = Fernet(key)
    with open(filename, 'rb') as file:
        # читать зашифрованные данные
        encrypted_data = file.read()
    # расшифровать данные
    decrypted_data = f.decrypt(encrypted_data)
    # записать оригинальный файл
    with open(filename, 'wb') as file:
        file.write(decrypted_data)

key = load_key()
# имя шифруемого файла
file = 'primercrypt.txt'

root = Tk()
root.geometry('500x500')
root.title('Какое-то приложение')

info = {'Логин' : 'Пароль'}

def login():
    label_login = Label(text='Войдите в систему')
    label_enter_login = Label(text='Введите логин')
    entry_login = Entry()
    label_password = Label(text='Введите пароль')
    entry_password = Entry()
    entry_button = Button(text='Войти!', command=lambda: verify_log_pass())
    label_login.pack()
    label_enter_login.pack()
    entry_login.pack()
    label_password.pack()
    entry_password.pack()
    entry_button.pack()

    def verify_log_pass():
        if entry_login.get() in info:
            if entry_password.get() == info[entry_login.get()]:
                decrypt(file, key)
                messagebox.showinfo('Дешифр сработал!', 'Загляни в документ, все расшифровалось!:)')
            else:
                messagebox.showerror('Ошибка', 'Логин такой, а пароль другой:(')
        else:
            messagebox.showerror('Ошибка', "Ты не админ:(")
login()
root.mainloop()