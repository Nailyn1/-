from cryptography.fernet import Fernet
from tkinter import *
from tkinter import messagebox

def write_key():
# Создаем ключ и сохраняем его в файл
    key = Fernet.generate_key()
    with open('crypto.key', 'wb') as key_file:
        key_file.write(key)
def load_key():
# Загружаем ключ 'crypto.key' из текущего каталога
    return open('crypto.key', 'rb').read()

def encrypt(filename, key):
# Зашифруем файл и записываем его
    f = Fernet(key)
    with open(filename, 'rb') as file:
    # прочитать все данные файла
        file_data = file.read()
        encrypted_data = f.encrypt(file_data)
    # записать зашифрованный файл
    with open(filename, 'wb') as file:
        file.write(encrypted_data)

def decrypt(filename, key):
# Расшифруем файл и записываем его
    f = Fernet(key)
    with open(filename, 'rb') as file:
        # читать зашифрованные данные
        encrypted_data = file.read()
    # расшифровать данные
    decrypted_data = f.decrypt(encrypted_data)
    # записать оригинальный файл
    with open(filename, 'wb') as file:
        file.write(decrypted_data)

key = load_key()
file = 'text.txt'

root = Tk()
root.geometry('500x500')
root.title('Зашифровать и расшифровать')


def DeandCrypt():
    crypt_button = Button(text=" Зашифровать", background="#555", foreground="#ccc",
                 padx="20", pady="8", font="16", command=lambda: crypt())
    decrypt_button = Button(text=" Расшифровать", background="#555", foreground="#ccc",
                          padx="20", pady="8", font="16", command=lambda: DEcrypt())
    crypt_button.place(relx=.5, rely=.5, anchor="c", height=30, width=150, bordermode=OUTSIDE)
    decrypt_button.place(relx=.5, rely=.4, anchor="c", height=30, width=150, bordermode=OUTSIDE)
    text = Text(width=50, height=10)
    text.pack()
    def crypt():
        encrypt(file, key)
        messagebox.showinfo('Зашифровано', 'Файл зашифровался!')
        messagebox.showinfo('Ключ', key)
        stroka = open('text.txt', 'r')
        text.insert(1.0, stroka.read())
    def DEcrypt():
        decrypt(file, key)
        messagebox.showinfo('Расшифровано', 'Файл расшифровался!')
        messagebox.showinfo('Ключ', key)
        text.delete(1.0, END)
        stroka = open('text.txt', 'r')
        text.insert(1.0, stroka.read())

DeandCrypt()
root.mainloop()